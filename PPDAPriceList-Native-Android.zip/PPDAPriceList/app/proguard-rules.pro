# Keep Gson models
-keepclassmembers class com.ppda.pricelist.data.** { *; }
-keep class com.google.gson.** { *; }
