# Keep data classes used by Gson
-keepclassmembers class com.ppda.pricelist.data.** { <fields>; }
-keep class com.ppda.pricelist.data.** { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Compose / Kotlin
-dontwarn kotlin.**
-keep class kotlin.Metadata { *; }
