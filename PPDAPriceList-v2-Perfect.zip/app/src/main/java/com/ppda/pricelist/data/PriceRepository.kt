package com.ppda.pricelist.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStreamReader

class PriceRepository(private val context: Context) {

    private var cachedItems: List<PriceItem>? = null

    suspend fun loadItems(): List<PriceItem> = withContext(Dispatchers.IO) {
        cachedItems?.let { return@withContext it }

        val inputStream = context.assets.open("ppda_prices.json")
        val reader = InputStreamReader(inputStream)
        val type = object : TypeToken<List<PriceItem>>() {}.type
        val items: List<PriceItem> = Gson().fromJson(reader, type)
        reader.close()
        cachedItems = items
        items
    }

    suspend fun getCategories(): List<String> {
        val items = loadItems()
        return items.map { it.category }.distinct().sorted()
    }
}
