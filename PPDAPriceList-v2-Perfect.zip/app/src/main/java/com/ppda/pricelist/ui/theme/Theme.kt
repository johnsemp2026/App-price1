package com.ppda.pricelist.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Brand colours matching the logo
val Navy = Color(0xFF1A365D)
val NavyLight = Color(0xFF2C5282)
val Gold = Color(0xFFF6AD55)
val AccentOrange = Color(0xFFED8936)
val SoftBg = Color(0xFFF7FAFC)
val CardWhite = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1A202C)
val Muted = Color(0xFF718096)

private val LightColorScheme = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    primaryContainer = NavyLight,
    onPrimaryContainer = Color.White,
    secondary = Gold,
    onSecondary = Navy,
    secondaryContainer = Color(0xFFFFE4B5),
    onSecondaryContainer = Navy,
    tertiary = AccentOrange,
    background = SoftBg,
    onBackground = TextDark,
    surface = CardWhite,
    onSurface = TextDark,
    surfaceVariant = Color(0xFFEDF2F7),
    onSurfaceVariant = Muted,
    outline = Color(0xFFE2E8F0)
)

private val DarkColorScheme = darkColorScheme(
    primary = Gold,
    onPrimary = Navy,
    primaryContainer = NavyLight,
    onPrimaryContainer = Color.White,
    secondary = Gold,
    onSecondary = Navy,
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFE2E8F0),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFE2E8F0),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFF94A3B8)
)

@Composable
fun PPDAPriceListTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
