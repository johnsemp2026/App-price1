package com.ppda.pricelist.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ppda.pricelist.data.PriceItem
import com.ppda.pricelist.data.PriceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val isLoading: Boolean = true,
    val allItems: List<PriceItem> = emptyList(),
    val filteredItems: List<PriceItem> = emptyList(),
    val categories: List<String> = emptyList(),
    val selectedCategory: String? = null,
    val searchQuery: String = "",
    val selectedItem: PriceItem? = null,
    val error: String? = null
)

class PriceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PriceRepository(application)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val items = repository.loadItems()
                val cats = repository.getCategories()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        allItems = items,
                        filteredItems = items,
                        categories = cats,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, error = "Failed to load price data: ${e.message}")
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        applyFilters()
    }

    fun onCategorySelected(category: String?) {
        _uiState.update { it.copy(selectedCategory = category) }
        applyFilters()
    }

    fun onItemClick(item: PriceItem) {
        _uiState.update { it.copy(selectedItem = item) }
    }

    fun onDismissDetail() {
        _uiState.update { it.copy(selectedItem = null) }
    }

    private fun applyFilters() {
        val state = _uiState.value
        val filtered = state.allItems.filter { item ->
            val matchesCategory = state.selectedCategory == null ||
                    item.category == state.selectedCategory
            val matchesSearch = item.matches(state.searchQuery)
            matchesCategory && matchesSearch
        }
        _uiState.update { it.copy(filteredItems = filtered) }
    }
}
