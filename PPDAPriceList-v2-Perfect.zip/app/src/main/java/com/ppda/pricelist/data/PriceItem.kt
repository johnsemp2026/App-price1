package com.ppda.pricelist.data

import com.google.gson.annotations.SerializedName

data class PriceItem(
    val code: String = "",
    val category: String = "",
    val name: String = "",
    val details: String = "",
    val qty: String = "",
    val units: String = "",
    val kampala: Long = 0,
    val mbarara: Long = 0,
    val mbale: Long = 0,
    val gulu: Long = 0,
    val average: Long = 0
) {
    fun matches(query: String): Boolean {
        if (query.isBlank()) return true
        val q = query.trim().lowercase()
        return code.lowercase().contains(q) ||
                name.lowercase().contains(q) ||
                details.lowercase().contains(q) ||
                category.lowercase().contains(q) ||
                units.lowercase().contains(q)
    }

    fun displayName(): String {
        return if (details.isNotBlank()) "$name - $details" else name
    }
}
