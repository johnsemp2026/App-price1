# PPDA Price List – Native Android App

**Fully offline** native Android app for the **PPDA Uganda Common User Items Average Prices (FY 2019/20)**.

Version **2.0.0**

---

## Features

- 100% offline (no internet needed after install)
- Fast search by item name, code, details or category
- Category filter chips
- Regional prices: **Kampala, Mbarara, Mbale, Gulu** + Average
- Clean Material 3 UI with PPDA Supplies Store branding
- 1,080 official items from the PPDA survey
- Native Kotlin + Jetpack Compose (not a web wrapper)

---

## Download the APK (easiest way)

1. Go to the **[Releases](../../releases)** page of this repository
2. Download the **Release APK** (or Debug APK)
3. On your Android phone open the file and install

> If GitHub Actions has already run, the APK will be attached to the release automatically.

---

## How to build yourself (Android Studio)

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer (or Ladybug / latest)
- JDK 17

### Steps
1. Clone or download this repository
2. Open the **root folder** (the one that contains `settings.gradle.kts`) in Android Studio
3. Let Gradle sync finish
4. Connect a device or start an emulator (API 24+)
5. Click **Run** ▶

### Generate APK
- **Debug**: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
- **Release** (signed): `Build → Generate Signed Bundle / APK`

Or from terminal:
```bash
./gradlew assembleDebug     # → app/build/outputs/apk/debug/
./gradlew assembleRelease   # → app/build/outputs/apk/release/
```

---

## GitHub Actions (automatic builds)

Every push to `main` and every tag starting with `v` (e.g. `v2.0.0`) will:

1. Build both Debug and Release APKs
2. Upload them as artifacts
3. Create a GitHub Release and attach the APKs automatically

You can also trigger it manually from the **Actions** tab → “Build & Release APK” → Run workflow.

---

## Project structure

```
PPDAPriceList/
├── app/
│   └── src/main/
│       ├── assets/ppda_prices.json   ← 1080 items
│       ├── java/com/ppda/pricelist/
│       │   ├── MainActivity.kt
│       │   ├── data/
│       │   └── ui/
│       └── res/
├── .github/workflows/build-apk.yml
├── gradlew
└── ...
```

---

## Notes

- Prices are **indicative averages** from the official PPDA 2019/20 survey.
- Always verify current market rates before any procurement decision.
- The app is completely self-contained.

---

Built as a true native Android app (Kotlin + Jetpack Compose).
